#include <stdio.h>

int main() {
  printf("Hello, (flake)!\n");
  return 0;
}
